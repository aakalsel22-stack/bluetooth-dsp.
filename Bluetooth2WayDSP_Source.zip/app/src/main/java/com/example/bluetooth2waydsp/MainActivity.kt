package com.example.bluetooth2waydsp

import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var engine: PcmPlayer
    private lateinit var status: TextView
    private lateinit var fileLabel: TextView
    private var selected: Uri? = null
    private var cutoff = 120
    private var lowGain = 0f
    private var highGain = 0f
    private var highPhase = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 14, 19)
        window.navigationBarColor = Color.rgb(12, 14, 19)
        engine = PcmPlayer(contentResolver) { msg -> runOnUiThread { status.text = msg } }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            setBackgroundColor(Color.rgb(12, 14, 19))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(0, dp(7), 0, dp(7))
            }
        page.addView(label("BLUETOOTH 2-WAY DSP", 22f, Color.WHITE, true))
        page.addView(label("MUSIC PLAYER  •  ACTIVE CROSSOVER", 11f, Color.rgb(120,170,255), true))

        val choose = Button(this).apply {
            text = "PILIH FILE MUSIK"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(i, 10)
            }
        }
        page.addView(choose, matchWrap())
        fileLabel = label("Belum ada file dipilih", 13f, Color.LTGRAY)
        page.addView(fileLabel)

        page.addView(label("CROSSOVER FREQUENCY", 14f, Color.WHITE, true))
        val freqText = label("$cutoff Hz", 20f, Color.rgb(92,220,177), true)
        page.addView(freqText)
        val freq = SeekBar(this).apply {
            max = 4960
            progress = cutoff - 40
            setOnSeekBarChangeListener(simpleSeek { value ->
                cutoff = value + 40
                freqText.text = "$cutoff Hz"
                engine.setCrossover(cutoff)
            })
        }
        page.addView(freq, matchWrap())

        page.addView(label("LOW OUTPUT  •  BLUETOOTH LEFT / SUB", 14f, Color.rgb(92,220,177), true))
        val lowText = label("LOW gain: 0.0 dB", 13f, Color.WHITE)
        page.addView(lowText)
        page.addView(SeekBar(this).apply {
            max = 240; progress = 120
            setOnSeekBarChangeListener(simpleSeek {
                lowGain = (it - 120) / 10f
                lowText.text = "LOW gain: %.1f dB".format(lowGain)
                engine.setGains(lowGain, highGain)
            })
        }, matchWrap())

        page.addView(label("HIGH OUTPUT  •  BLUETOOTH RIGHT / MID-TWEETER", 14f, Color.rgb(125,175,255), true))
        val highText = label("HIGH gain: 0.0 dB", 13f, Color.WHITE)
        page.addView(highText)
        page.addView(SeekBar(this).apply {
            max = 240; progress = 120
            setOnSeekBarChangeListener(simpleSeek {
                highGain = (it - 120) / 10f
                highText.text = "HIGH gain: %.1f dB".format(highGain)
                engine.setGains(lowGain, highGain)
            })
        }, matchWrap())

        val phase = Button(this).apply {
            text = "PHASE HIGH: 0°"
            setOnClickListener {
                highPhase = !highPhase
                text = if (highPhase) "PHASE HIGH: 180°" else "PHASE HIGH: 0°"
                engine.setHighPhase(highPhase)
            }
        }
        page.addView(phase, matchWrap())

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(Button(this).apply {
            text = "▶ PLAY"
            setOnClickListener {
                val uri = selected
                if (uri == null) status.text = "Pilih file musik terlebih dahulu"
                else engine.play(uri)
            }
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        controls.addView(Button(this).apply {
            text = "■ STOP"
            setOnClickListener { engine.stop() }
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        page.addView(controls)

        status = label("Status: siap • Hubungkan Bluetooth sebelum PLAY", 12f, Color.LTGRAY)
        page.addView(status)
        page.addView(label(
            "PENTING: Pairing Bluetooth dilakukan dari pengaturan Android. " +
            "Kiri = LOW, kanan = HIGH. Gunakan penerima Bluetooth stereo yang memisahkan L/R ke dua input amplifier.",
            12f, Color.rgb(255,190,110)
        ))

        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(8) }

    private fun simpleSeek(block: (Int) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) block(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            selected = data?.data
            selected?.let {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                fileLabel.text = it.lastPathSegment ?: "File musik dipilih"
                status.text = "File siap diputar"
            }
        }
    }

    override fun onDestroy() {
        engine.release()
        super.onDestroy()
    }
}
