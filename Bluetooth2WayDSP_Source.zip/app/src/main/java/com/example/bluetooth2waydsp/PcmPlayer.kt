package com.example.bluetooth2waydsp

import android.content.ContentResolver
import android.media.*
import android.net.Uri
import android.os.Process
import java.nio.ByteOrder
import kotlin.math.*

/**
 * PCM decoder + LR4 crossover.
 * Bluetooth routing is handled by Android's normal media output route.
 * Output mapping: left = mono LOW, right = mono HIGH.
 */
class PcmPlayer(
    private val resolver: ContentResolver,
    private val onStatus: (String) -> Unit
) {
    @Volatile private var running = false
    @Volatile private var stopRequested = false
    @Volatile private var cutoffHz = 120
    @Volatile private var lowDb = 0f
    @Volatile private var highDb = 0f
    @Volatile private var invertHigh = false
    private var worker: Thread? = null
    private var track: AudioTrack? = null

    fun setCrossover(hz: Int) { cutoffHz = hz.coerceIn(40, 5000) }
    fun setGains(low: Float, high: Float) { lowDb = low; highDb = high }
    fun setHighPhase(invert: Boolean) { invertHigh = invert }

    @Synchronized fun play(uri: Uri) {
        stop()
        stopRequested = false
        worker = Thread({ decodeAndPlay(uri) }, "DSP-Decoder").also { it.start() }
    }

    @Synchronized fun stop() {
        stopRequested = true
        running = false
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
        try { worker?.join(400) } catch (_: Exception) {}
        worker = null
        track?.release()
        track = null
    }

    private fun decodeAndPlay(uri: Uri) {
        var extractor: MediaExtractor? = null
        var decoder: MediaCodec? = null
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            extractor = MediaExtractor()
            resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                extractor.setDataSource(pfd.fileDescriptor)
            } ?: throw IllegalStateException("Tidak dapat membuka file")

            var audioTrackIndex = -1
            var mime: String? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("audio/")) {
                    audioTrackIndex = i; mime = m; break
                }
            }
            if (audioTrackIndex < 0 || mime == null) throw IllegalArgumentException("Track audio tidak ditemukan")
            extractor.selectTrack(audioTrackIndex)
            val inputFormat = extractor.getTrackFormat(audioTrackIndex)
            val sampleRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()

            val minBuffer = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer <= 0) throw IllegalStateException("Format audio tidak didukung")
            val audioOut = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(minBuffer * 4)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = audioOut
            audioOut.play()
            running = true
            onStatus("Memutar • output Bluetooth mengikuti pilihan audio Android")

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var sampleRateOut = sampleRate
            var leftLow = BiquadCascade()
            var rightLow = BiquadCascade()
            var leftHigh = BiquadCascade()
            var rightHigh = BiquadCascade()
            var activeCutoff = -1
            var activeRate = -1

            while (!outputDone && !stopRequested) {
                if (!inputDone) {
                    val inIndex = decoder.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val inBuf = decoder.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(inBuf, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIndex = decoder.dequeueOutputBuffer(info, 10_000)
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val fmt = decoder.outputFormat
                    sampleRateOut = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    val channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (channels !in 1..2) throw IllegalArgumentException("Audio harus mono atau stereo")
                    if (sampleRateOut != sampleRate) throw IllegalArgumentException("Sample rate berubah; file ini belum didukung")
                } else if (outIndex >= 0) {
                    val outBuf = decoder.getOutputBuffer(outIndex)!!
                    if (info.size > 0) {
                        outBuf.position(info.offset)
                        outBuf.limit(info.offset + info.size)
                        val pcm = outBuf.slice().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        val channels = decoder.outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        val frames = pcm.remaining() / channels
                        val bytes = ByteArray(frames * 4)
                        val bb = java.nio.ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                        val currentCutoff = cutoffHz
                        if (activeCutoff != currentCutoff || activeRate != sampleRateOut) {
                            leftLow = BiquadCascade(sampleRateOut, currentCutoff, true)
                            rightLow = BiquadCascade(sampleRateOut, currentCutoff, true)
                            leftHigh = BiquadCascade(sampleRateOut, currentCutoff, false)
                            rightHigh = BiquadCascade(sampleRateOut, currentCutoff, false)
                            activeCutoff = currentCutoff; activeRate = sampleRateOut
                        }
                        val lg = 10.0.pow(lowDb / 20.0).toFloat()
                        val hg = 10.0.pow(highDb / 20.0).toFloat() * if (invertHigh) -1f else 1f
                        repeat(frames) {
                            val mono = if (channels == 1) pcm.get().toFloat() / 32768f
                                else ((pcm.get().toInt() + pcm.get().toInt()) / 2f) / 32768f
                            val low = (leftLow.process(mono) * lg).coerceIn(-1f, 1f)
                            val high = (leftHigh.process(mono) * hg).coerceIn(-1f, 1f)
                            bb.putShort((low * 32767f).toInt().toShort())  // Bluetooth LEFT = LOW
                            bb.putShort((high * 32767f).toInt().toShort()) // Bluetooth RIGHT = HIGH
                        }
                        bb.flip()
                        while (bb.hasRemaining() && !stopRequested) {
                            audioOut.write(bb, bb.remaining(), AudioTrack.WRITE_BLOCKING)
                        }
                    }
                    outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    decoder.releaseOutputBuffer(outIndex, false)
                }
            }
            onStatus(if (stopRequested) "Dihentikan" else "Selesai")
        } catch (e: Exception) {
            onStatus("Error: ${e.message ?: "pemutaran gagal"}")
        } finally {
            running = false
            try { decoder?.stop() } catch (_: Exception) {}
            try { decoder?.release() } catch (_: Exception) {}
            try { extractor?.release() } catch (_: Exception) {}
            try { track?.stop(); track?.release() } catch (_: Exception) {}
            track = null
        }
    }

    @Synchronized fun release() { stop() }
}

/** Two cascaded Butterworth biquads = Linkwitz-Riley 4th order. */
private class BiquadCascade(
    sampleRate: Int = 48000,
    cutoff: Int = 120,
    lowPass: Boolean = true
) {
    private val a = Biquad(sampleRate, cutoff, lowPass)
    private val b = Biquad(sampleRate, cutoff, lowPass)
    fun process(x: Float) = b.process(a.process(x))
}

private class Biquad(sampleRate: Int, cutoff: Int, lowPass: Boolean) {
    private val b0: Float
    private val b1: Float
    private val b2: Float
    private val a1: Float
    private val a2: Float
    private var x1 = 0f; private var x2 = 0f
    private var y1 = 0f; private var y2 = 0f

    init {
        val f = cutoff.coerceIn(20, (sampleRate / 2 - 100).coerceAtLeast(21)).toDouble()
        val w = 2.0 * PI * f / sampleRate
        val c = cos(w); val s = sin(w)
        val alpha = s / (2.0 * sqrt(0.5))
        val bb0: Double; val bb1: Double; val bb2: Double
        if (lowPass) {
            bb0 = (1 - c) / 2; bb1 = 1 - c; bb2 = (1 - c) / 2
        } else {
            bb0 = (1 + c) / 2; bb1 = -(1 + c); bb2 = (1 + c) / 2
        }
        val aa0 = 1 + alpha
        b0 = (bb0 / aa0).toFloat(); b1 = (bb1 / aa0).toFloat()
        b2 = (bb2 / aa0).toFloat(); a1 = (-2 * c / aa0).toFloat()
        a2 = ((1 - alpha) / aa0).toFloat()
    }

    fun process(x: Float): Float {
        val y = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }
}
