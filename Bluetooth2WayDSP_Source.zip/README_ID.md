# Bluetooth 2-Way DSP Music Player (Android)

## Fungsi
- Memilih file audio lokal melalui Android Storage Access Framework.
- Decode audio menggunakan MediaExtractor + MediaCodec.
- DSP crossover Linkwitz-Riley 4th order (dua biquad Butterworth per jalur).
- Output stereo Bluetooth: kanal kiri = LOW, kanal kanan = HIGH.
- Frekuensi 40–5000 Hz, gain masing-masing jalur -12 sampai +12 dB, phase HIGH 0/180 derajat.

## Batasan penting
1. Ini adalah crossover mono: audio kiri dan kanan sumber dijumlahkan menjadi mono, lalu dibagi frekuensinya.
2. Bluetooth A2DP mengirim satu stream stereo ke satu penerima/rute aktif. Aplikasi tidak dapat menjamin sinkronisasi dua speaker Bluetooth terpisah.
3. Gunakan satu receiver Bluetooth stereo yang mengeluarkan L/R analog terpisah, lalu hubungkan L ke amplifier LOW dan R ke amplifier HIGH.
4. Jangan hubungkan tweeter langsung ke output tanpa amplifier dan proteksi yang sesuai. Atur gain rendah saat pengujian.
5. Android dapat menerapkan volume, codec Bluetooth, resampling, dan pemrosesan tambahan. Untuk sistem audio mobil/PA kritis, DSP hardware lebih disarankan.
6. Proyek ini adalah starter source yang perlu diuji pada perangkat Android dan file audio yang digunakan. Tidak disertakan APK yang sudah ditandatangani.

## Membuat APK melalui Android Studio
1. Instal Android Studio versi stabil dan Android SDK Platform 35.
2. Ekstrak folder `Bluetooth2WayDSP.zip`.
3. Android Studio > Open > pilih folder `Bluetooth2WayDSP`.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Build-Tools/Platform 35.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik `locate` pada notifikasi Build. APK debug biasanya ada di:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Pindahkan APK ke HP, izinkan instalasi dari sumber tersebut, lalu instal.

## Membuat APK release
Android Studio > Build > Generate Signed Bundle / APK > APK > buat atau pilih keystore > pilih release > Finish.
Simpan file keystore dan password dengan aman. Kehilangan keystore dapat menyulitkan pembaruan aplikasi.

## Cara memakai
1. Pairing receiver Bluetooth stereo dari Settings Android.
2. Hubungkan output L receiver ke amplifier LOW dan output R ke amplifier HIGH.
3. Buka aplikasi dan pilih file musik.
4. Mulai dari volume rendah. Set crossover awal, misalnya 120 Hz untuk uji subwoofer + speaker atas (sesuaikan driver).
5. Atur gain LOW/HIGH dan phase sesuai pengukuran serta karakter sistem.
6. Jika suara bass atau high tidak muncul, periksa routing Bluetooth, kabel L/R, amplifier, dan kompatibilitas codec.

## Catatan build
- Namespace: `com.example.bluetooth2waydsp`
- Min SDK: 26 (Android 8.0)
- Target SDK: 35
- Kotlin + Android SDK native; tidak memakai library eksternal.
